public class Shift{
   private CalendarTime start;
   private CalendarTime finish;
      
   public Shift(CalendarTime start, CalendarTime finish){
      this.start=start;
      this.finish=finish;
                 
   }
   public CalendarTime start(){
            return this.start;
   }
   
   public CalendarTime finish(){
         return this.finish;
   }         
      
   public boolean includesDate(Date d){
      Date d1= (this.start).date();
      Date d2=(this.finish).date();
      if((d.compareTo(d1)>=0)&&(d.compareTo(d2)<=0)){
                     return true;
         
      }
      return false;
                     
   }
   
   public boolean inWeek(Week w){
      Date d1= (this.start).date();
      Date d2=(this.finish).date();
      if ((w.includes(d1))||(w.includes(d2))){
            return true;              
      }
      return false;         
      
   }
   
   public Duration length(){
            Duration d=(this.finish).subtract(this.start);
            return d;
   }
            
            
   public String toString(){
         return ((this.start).toString()+" "+"-"+" " +(this.finish).toString());
   }
      


}