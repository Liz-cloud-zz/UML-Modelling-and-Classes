import java.util.ArrayList;
import java.util.Iterator;
import java.util.*;
import java.util.ListIterator;
import java.util.List;


public class Employee{

   private String name;
   private String UID;
   List<Shift> s=new ArrayList<Shift>();
   CalendarTime start;
   CalendarTime finish;
   boolean signedIn;
   boolean signedOut;
   
   public Employee(String name, String UID){
      this.name=name;
      this.UID=UID;
            
   }
      
   public String name(){
      return this.name;
   }
      
   public String UID(){
      return this.UID;
   }

      
   public void signIn(Date d1 , Time t1 ){
      start= new CalendarTime(d1,t1); 
      signedIn=true;
   }
      
   public void signOut(Date d2, Time t2){
      finish= new CalendarTime(d2,t2);
      signedOut=true;
      s.add(new Shift (start, finish));
   }
   
         
   public boolean present(){
      if((signedIn==true)&&(signedOut==false)){
         return true;
      }
      return false;
   }
      
   public boolean  worked(Date d){
      for (Shift sh :s){
         if (sh.includesDate(d)){
            return true;
         }
      
      }
      return false;   
   }
       
   public boolean worked(Week w){
      for (Shift sh :s){
         if (sh.inWeek(w)){
            return true;
         }
      
      }
      return false;
   
   }
   
   public List<Shift> get(Date d){
      List<Shift> slot=new ArrayList<Shift>();  
      for (Shift sh :s){
         if (sh.includesDate(d)){
            slot.add(sh);      
         }
      }     
      return slot;  
   
   }
   
   public List<Shift> get(Week w){
      List<Shift> slot=new ArrayList<Shift>();
      for (Shift sh :s){
         if (sh.inWeek(w)){
            slot.add(sh);      
         }
      }    
   
      return slot;
   }
   
   public Duration hours(Week w){
      Duration d = Duration.ZERO;
      List<Shift> list= this.get(w);
      for (Shift sh:list){
         d = d.add((sh).length());
      }
      return d;      
   
   }   

}